﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Npgsql;

namespace ekutuphane
{
    class NpgDB
    {
        public bool kitapguncelle(int kitapid, string isbn, string yazar, string kitapadi, string kategori, string pdfadres)
        {
            
            using(var cn = GetConnection())
            {
                cn.Open();

                string sorgu = "call kitapguncelle (" + $"{kitapid}" + "," + $"'{isbn}'" + "," + $"'{yazar}'" + "," + $"'{kitapadi}'" + "," + $"'{kategori}'" + "," + $"'{pdfadres}'" +")";

                NpgsqlCommand cmd = new NpgsqlCommand(sorgu, cn);

                int i = cmd.ExecuteNonQuery();
                cn.Close();
                bool a = false;
                if (i == 1)
                {
                    a = true;
                }

                return a;
            }
            
        }

        public bool kitapekle(string isbn, string yazar, string kitapadi, string kategori, string pdfadres)
        {

            using (var cn = GetConnection())
            {
                cn.Open();

                string sorgu = "call kitapekle (" + $"'{isbn}'" + "," + $"'{yazar}'" + "," + $"'{kitapadi}'" + "," + $"'{kategori}'" + "," + $"'{pdfadres}'" + ")";

                NpgsqlCommand cmd = new NpgsqlCommand(sorgu, cn);

                int i = cmd.ExecuteNonQuery();
                cn.Close();
                bool a = false;
                if (i == 1)
                {
                    a = true;
                }

                return a;
            }

        }
        public bool kitapsil(int kitapid)
        {

            using (var cn = GetConnection())
            {
                cn.Open();

                string sorgu = "call kitapsil(" + $"'{kitapid}'" + ")";

                NpgsqlCommand cmd = new NpgsqlCommand(sorgu, cn);

                int i = cmd.ExecuteNonQuery();
                cn.Close();
                bool a = false;
                if (i == 1)
                {
                    a = true;
                }

                return a;
            }

        }
        public static NpgsqlConnection GetConnection()
        {
            return new NpgsqlConnection("Host=localhost;Username=postgres;Password=123;Database=kutupdb");
        }
    }
}
