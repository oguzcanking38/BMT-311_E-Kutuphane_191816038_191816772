﻿namespace ekutuphane
{
    partial class Sifreunut
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.materialLabel1 = new MaterialSkin.Controls.MaterialLabel();
            this.textemail = new System.Windows.Forms.TextBox();
            this.gonderbuton = new MaterialSkin.Controls.MaterialFlatButton();
            this.label1 = new System.Windows.Forms.Label();
            this.texttc = new System.Windows.Forms.TextBox();
            this.materialLabel2 = new MaterialSkin.Controls.MaterialLabel();
            this.SuspendLayout();
            // 
            // materialLabel1
            // 
            this.materialLabel1.AutoSize = true;
            this.materialLabel1.Depth = 0;
            this.materialLabel1.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel1.Location = new System.Drawing.Point(45, 139);
            this.materialLabel1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel1.Name = "materialLabel1";
            this.materialLabel1.Size = new System.Drawing.Size(47, 19);
            this.materialLabel1.TabIndex = 0;
            this.materialLabel1.Text = "Email";
            // 
            // textemail
            // 
            this.textemail.Location = new System.Drawing.Point(106, 138);
            this.textemail.Name = "textemail";
            this.textemail.Size = new System.Drawing.Size(221, 20);
            this.textemail.TabIndex = 1;
            // 
            // gonderbuton
            // 
            this.gonderbuton.AutoSize = true;
            this.gonderbuton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.gonderbuton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gonderbuton.Depth = 0;
            this.gonderbuton.Font = new System.Drawing.Font("Microsoft Sans Serif", 5.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.gonderbuton.Location = new System.Drawing.Point(342, 118);
            this.gonderbuton.Margin = new System.Windows.Forms.Padding(0);
            this.gonderbuton.MinimumSize = new System.Drawing.Size(20, 40);
            this.gonderbuton.MouseState = MaterialSkin.MouseState.HOVER;
            this.gonderbuton.Name = "gonderbuton";
            this.gonderbuton.Primary = false;
            this.gonderbuton.Size = new System.Drawing.Size(66, 40);
            this.gonderbuton.TabIndex = 2;
            this.gonderbuton.Text = "Gönder";
            this.gonderbuton.UseVisualStyleBackColor = true;
            this.gonderbuton.Click += new System.EventHandler(this.gonderbuton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(170, 166);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(157, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "*E-Mailinize Kod Gönderilecektir";
            // 
            // texttc
            // 
            this.texttc.Location = new System.Drawing.Point(106, 107);
            this.texttc.Name = "texttc";
            this.texttc.Size = new System.Drawing.Size(221, 20);
            this.texttc.TabIndex = 4;
            // 
            // materialLabel2
            // 
            this.materialLabel2.AutoSize = true;
            this.materialLabel2.Depth = 0;
            this.materialLabel2.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel2.Location = new System.Drawing.Point(43, 107);
            this.materialLabel2.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel2.Name = "materialLabel2";
            this.materialLabel2.Size = new System.Drawing.Size(49, 19);
            this.materialLabel2.TabIndex = 5;
            this.materialLabel2.Text = "TC no";
            // 
            // Sifreunut
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(454, 244);
            this.Controls.Add(this.materialLabel2);
            this.Controls.Add(this.texttc);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.gonderbuton);
            this.Controls.Add(this.textemail);
            this.Controls.Add(this.materialLabel1);
            this.Name = "Sifreunut";
            this.Text = " ";
            this.Load += new System.EventHandler(this.Sifreunut_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MaterialSkin.Controls.MaterialLabel materialLabel1;
        private System.Windows.Forms.TextBox textemail;
        private MaterialSkin.Controls.MaterialFlatButton gonderbuton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox texttc;
        private MaterialSkin.Controls.MaterialLabel materialLabel2;
    }
}