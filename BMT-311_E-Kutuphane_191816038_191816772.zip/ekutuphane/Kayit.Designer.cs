﻿namespace ekutuphane
{
    partial class Kayit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.materialLabel1 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel2 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel3 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel4 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel5 = new MaterialSkin.Controls.MaterialLabel();
            this.textad = new System.Windows.Forms.TextBox();
            this.textsoyad = new System.Windows.Forms.TextBox();
            this.textemail = new System.Windows.Forms.TextBox();
            this.texttel = new System.Windows.Forms.TextBox();
            this.textadres = new System.Windows.Forms.TextBox();
            this.materialLabel6 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel7 = new MaterialSkin.Controls.MaterialLabel();
            this.textsifre = new System.Windows.Forms.TextBox();
            this.textsifre2 = new System.Windows.Forms.TextBox();
            this.kayitolbuton = new MaterialSkin.Controls.MaterialFlatButton();
            this.materialLabel8 = new MaterialSkin.Controls.MaterialLabel();
            this.textno = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // materialLabel1
            // 
            this.materialLabel1.AutoSize = true;
            this.materialLabel1.Depth = 0;
            this.materialLabel1.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel1.Location = new System.Drawing.Point(64, 106);
            this.materialLabel1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel1.Name = "materialLabel1";
            this.materialLabel1.Size = new System.Drawing.Size(50, 19);
            this.materialLabel1.TabIndex = 0;
            this.materialLabel1.Text = "Adınız";
            // 
            // materialLabel2
            // 
            this.materialLabel2.AutoSize = true;
            this.materialLabel2.Depth = 0;
            this.materialLabel2.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel2.Location = new System.Drawing.Point(64, 143);
            this.materialLabel2.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel2.Name = "materialLabel2";
            this.materialLabel2.Size = new System.Drawing.Size(73, 19);
            this.materialLabel2.TabIndex = 1;
            this.materialLabel2.Text = "Soyadınız";
            // 
            // materialLabel3
            // 
            this.materialLabel3.AutoSize = true;
            this.materialLabel3.Depth = 0;
            this.materialLabel3.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel3.Location = new System.Drawing.Point(64, 180);
            this.materialLabel3.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel3.Name = "materialLabel3";
            this.materialLabel3.Size = new System.Drawing.Size(51, 19);
            this.materialLabel3.TabIndex = 2;
            this.materialLabel3.Text = "E-Mail";
            // 
            // materialLabel4
            // 
            this.materialLabel4.AutoSize = true;
            this.materialLabel4.Depth = 0;
            this.materialLabel4.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel4.Location = new System.Drawing.Point(64, 217);
            this.materialLabel4.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel4.Name = "materialLabel4";
            this.materialLabel4.Size = new System.Drawing.Size(129, 19);
            this.materialLabel4.TabIndex = 3;
            this.materialLabel4.Text = "Telefon Numarası";
            // 
            // materialLabel5
            // 
            this.materialLabel5.AutoSize = true;
            this.materialLabel5.Depth = 0;
            this.materialLabel5.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel5.Location = new System.Drawing.Point(64, 254);
            this.materialLabel5.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel5.Name = "materialLabel5";
            this.materialLabel5.Size = new System.Drawing.Size(48, 19);
            this.materialLabel5.TabIndex = 4;
            this.materialLabel5.Text = "Adres";
            // 
            // textad
            // 
            this.textad.Location = new System.Drawing.Point(226, 104);
            this.textad.Name = "textad";
            this.textad.Size = new System.Drawing.Size(247, 20);
            this.textad.TabIndex = 5;
            // 
            // textsoyad
            // 
            this.textsoyad.Location = new System.Drawing.Point(226, 144);
            this.textsoyad.Name = "textsoyad";
            this.textsoyad.Size = new System.Drawing.Size(247, 20);
            this.textsoyad.TabIndex = 6;
            // 
            // textemail
            // 
            this.textemail.Location = new System.Drawing.Point(226, 181);
            this.textemail.Name = "textemail";
            this.textemail.Size = new System.Drawing.Size(247, 20);
            this.textemail.TabIndex = 7;
            // 
            // texttel
            // 
            this.texttel.Location = new System.Drawing.Point(226, 216);
            this.texttel.Name = "texttel";
            this.texttel.Size = new System.Drawing.Size(247, 20);
            this.texttel.TabIndex = 8;
            // 
            // textadres
            // 
            this.textadres.Location = new System.Drawing.Point(226, 253);
            this.textadres.MaximumSize = new System.Drawing.Size(247, 100);
            this.textadres.MinimumSize = new System.Drawing.Size(247, 50);
            this.textadres.Name = "textadres";
            this.textadres.Size = new System.Drawing.Size(247, 20);
            this.textadres.TabIndex = 9;
            // 
            // materialLabel6
            // 
            this.materialLabel6.AutoSize = true;
            this.materialLabel6.Depth = 0;
            this.materialLabel6.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel6.Location = new System.Drawing.Point(64, 378);
            this.materialLabel6.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel6.Name = "materialLabel6";
            this.materialLabel6.Size = new System.Drawing.Size(40, 19);
            this.materialLabel6.TabIndex = 10;
            this.materialLabel6.Text = "Şifre";
            // 
            // materialLabel7
            // 
            this.materialLabel7.AutoSize = true;
            this.materialLabel7.Depth = 0;
            this.materialLabel7.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel7.Location = new System.Drawing.Point(64, 417);
            this.materialLabel7.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel7.Name = "materialLabel7";
            this.materialLabel7.Size = new System.Drawing.Size(87, 19);
            this.materialLabel7.TabIndex = 11;
            this.materialLabel7.Text = "Şifre Tekrar";
            // 
            // textsifre
            // 
            this.textsifre.Location = new System.Drawing.Point(226, 379);
            this.textsifre.Name = "textsifre";
            this.textsifre.PasswordChar = '*';
            this.textsifre.Size = new System.Drawing.Size(247, 20);
            this.textsifre.TabIndex = 12;
            // 
            // textsifre2
            // 
            this.textsifre2.Location = new System.Drawing.Point(226, 418);
            this.textsifre2.Name = "textsifre2";
            this.textsifre2.PasswordChar = '*';
            this.textsifre2.Size = new System.Drawing.Size(247, 20);
            this.textsifre2.TabIndex = 13;
            // 
            // kayitolbuton
            // 
            this.kayitolbuton.AutoSize = true;
            this.kayitolbuton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.kayitolbuton.Depth = 0;
            this.kayitolbuton.Location = new System.Drawing.Point(508, 380);
            this.kayitolbuton.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.kayitolbuton.MinimumSize = new System.Drawing.Size(80, 56);
            this.kayitolbuton.MouseState = MaterialSkin.MouseState.HOVER;
            this.kayitolbuton.Name = "kayitolbuton";
            this.kayitolbuton.Primary = false;
            this.kayitolbuton.Size = new System.Drawing.Size(80, 56);
            this.kayitolbuton.TabIndex = 14;
            this.kayitolbuton.Text = "Kayıt Ol";
            this.kayitolbuton.UseVisualStyleBackColor = true;
            this.kayitolbuton.Click += new System.EventHandler(this.kayitolbuton_Click);
            // 
            // materialLabel8
            // 
            this.materialLabel8.AutoSize = true;
            this.materialLabel8.Depth = 0;
            this.materialLabel8.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel8.Location = new System.Drawing.Point(64, 331);
            this.materialLabel8.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel8.Name = "materialLabel8";
            this.materialLabel8.Size = new System.Drawing.Size(75, 19);
            this.materialLabel8.TabIndex = 15;
            this.materialLabel8.Text = "Kimlik No";
            // 
            // textno
            // 
            this.textno.Location = new System.Drawing.Point(226, 331);
            this.textno.Name = "textno";
            this.textno.Size = new System.Drawing.Size(247, 20);
            this.textno.TabIndex = 16;
            // 
            // Kayit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(628, 479);
            this.Controls.Add(this.textno);
            this.Controls.Add(this.materialLabel8);
            this.Controls.Add(this.kayitolbuton);
            this.Controls.Add(this.textsifre2);
            this.Controls.Add(this.textsifre);
            this.Controls.Add(this.materialLabel7);
            this.Controls.Add(this.materialLabel6);
            this.Controls.Add(this.textadres);
            this.Controls.Add(this.texttel);
            this.Controls.Add(this.textemail);
            this.Controls.Add(this.textsoyad);
            this.Controls.Add(this.textad);
            this.Controls.Add(this.materialLabel5);
            this.Controls.Add(this.materialLabel4);
            this.Controls.Add(this.materialLabel3);
            this.Controls.Add(this.materialLabel2);
            this.Controls.Add(this.materialLabel1);
            this.Name = "Kayit";
            this.Text = "Kayıt Ol";
            this.Load += new System.EventHandler(this.Kayit_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MaterialSkin.Controls.MaterialLabel materialLabel1;
        private MaterialSkin.Controls.MaterialLabel materialLabel2;
        private MaterialSkin.Controls.MaterialLabel materialLabel3;
        private MaterialSkin.Controls.MaterialLabel materialLabel4;
        private MaterialSkin.Controls.MaterialLabel materialLabel5;
        private System.Windows.Forms.TextBox textad;
        private System.Windows.Forms.TextBox textsoyad;
        private System.Windows.Forms.TextBox textemail;
        private System.Windows.Forms.TextBox texttel;
        private System.Windows.Forms.TextBox textadres;
        private MaterialSkin.Controls.MaterialLabel materialLabel6;
        private MaterialSkin.Controls.MaterialLabel materialLabel7;
        private System.Windows.Forms.TextBox textsifre;
        private System.Windows.Forms.TextBox textsifre2;
        private MaterialSkin.Controls.MaterialFlatButton kayitolbuton;
        private MaterialSkin.Controls.MaterialLabel materialLabel8;
        private System.Windows.Forms.TextBox textno;
    }
}