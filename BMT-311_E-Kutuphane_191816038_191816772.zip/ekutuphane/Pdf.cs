﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MaterialSkin.Controls;


namespace ekutuphane
{
    public partial class Pdf : MaterialForm
    {
        public Pdf()
        {
            InitializeComponent();
        }

        private void Pdf_Load(object sender, EventArgs e)
        {
            axAcroPDF1.src = tc.pdflink;

        }

        private void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {

        }

        private void materialFlatButton1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
