﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MaterialSkin.Controls;
using Npgsql;
namespace ekutuphane
{
    public partial class Adminpanel : MaterialForm
    {
        string kitapid;
        string isbn;
        string yazar;
        string kitapadi;
        string kategori;
        string pdfadres;
        string dosyayolu;
        public Adminpanel()
        {
            InitializeComponent();
        }


        private void Adminpanel_Load(object sender, EventArgs e)
        {
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();

            var cs = "Host=localhost;Username=postgres;Password=123;Database=kutupdb";

            var con = new NpgsqlConnection(cs);

            con.Open();
            string sql = "SELECT * FROM kitaplar";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sql, con);
            ds.Reset();
            da.Fill(ds);
            dt = ds.Tables[0];
            dataGridView1.DataSource = dt;
            con.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AnaEkran kyt = new AnaEkran();
            kyt.Show();

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            dataGridView1.CurrentRow.Selected = true;

            kitapid = dataGridView1.Rows[e.RowIndex].Cells["kitapid"].FormattedValue.ToString();
            isbn = dataGridView1.Rows[e.RowIndex].Cells["isbn"].FormattedValue.ToString();
            yazar = dataGridView1.Rows[e.RowIndex].Cells["yazar"].FormattedValue.ToString();
            kitapadi = dataGridView1.Rows[e.RowIndex].Cells["kitapadi"].FormattedValue.ToString();
            kategori = dataGridView1.Rows[e.RowIndex].Cells["kategori"].FormattedValue.ToString();
            pdfadres = dataGridView1.Rows[e.RowIndex].Cells["pdfadres"].FormattedValue.ToString();

            txtisbn.Text = isbn;
            txtyaz.Text = yazar;
            txtkadi.Text = kitapadi;
            txtktg.Text = kategori;
            txtpdf.Text = pdfadres;


            
        }

        private void materialFlatButton1_Click(object sender, EventArgs e)
        {
            isbn = txtisbn.Text;
            yazar = txtyaz.Text;
            kitapadi = txtkadi.Text;
            kategori = txtktg.Text;
            pdfadres = txtpdf.Text;
            var npgdb = new NpgDB();
            int kitapid2 = Int32.Parse(kitapid);
            npgdb.kitapguncelle(kitapid2, isbn, yazar, kitapadi, kategori, pdfadres);

            DataSet ds = new DataSet();
            DataTable dt = new DataTable();

            var cs = "Host=localhost;Username=postgres;Password=123;Database=kutupdb";

            var con = new NpgsqlConnection(cs);

            con.Open();
            string sql = "SELECT * FROM kitaplar";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sql, con);
            ds.Reset();
            da.Fill(ds);
            dt = ds.Tables[0];
            dataGridView1.DataSource = dt;
            con.Close();

        }

        private void materialFlatButton4_Click(object sender, EventArgs e)
        {
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();

            var cs = "Host=localhost;Username=postgres;Password=123;Database=kutupdb";

            var con = new NpgsqlConnection(cs);

            con.Open();
            string sql = "SELECT * FROM kitaplar";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sql, con);
            ds.Reset();
            da.Fill(ds);
            dt = ds.Tables[0];
            dataGridView1.DataSource = dt;
            con.Close();

        }

        private void materialFlatButton3_Click(object sender, EventArgs e)
        {

            isbn = txtisbn.Text;
            yazar = txtyaz.Text;
            kitapadi = txtkadi.Text;
            kategori = txtktg.Text;
            pdfadres = txtpdf.Text;
            var npgdb = new NpgDB();
            npgdb.kitapekle(isbn, yazar, kitapadi, kategori, pdfadres);

            DataSet ds = new DataSet();
            DataTable dt = new DataTable();

            var cs = "Host=localhost;Username=postgres;Password=123;Database=kutupdb";

            var con = new NpgsqlConnection(cs);

            con.Open();
            string sql = "SELECT * FROM kitaplar";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sql, con);
            ds.Reset();
            da.Fill(ds);
            dt = ds.Tables[0];
            dataGridView1.DataSource = dt;
            con.Close();

        }

        private void materialFlatButton2_Click(object sender, EventArgs e)
        {
            var npgdb = new NpgDB();
            int kitapid2 = Int32.Parse(kitapid);
            npgdb.kitapsil(kitapid2);

            DataSet ds = new DataSet();
            DataTable dt = new DataTable();

            var cs = "Host=localhost;Username=postgres;Password=123;Database=kutupdb";

            var con = new NpgsqlConnection(cs);

            con.Open();
            string sql = "SELECT * FROM kitaplar";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sql, con);
            ds.Reset();
            da.Fill(ds);
            dt = ds.Tables[0];
            dataGridView1.DataSource = dt;
            con.Close();
        }

        private void materialFlatButton5_Click(object sender, EventArgs e)
        {

            txtisbn.Text = "";
            txtyaz.Text = "";
            txtkadi.Text = "";
            txtktg.Text = "";
            txtpdf.Text = "";

        }

        private void materialFlatButton6_Click(object sender, EventArgs e)
        {
            
            
            OpenFileDialog pdfsec = new OpenFileDialog();
            pdfsec.Filter = "PDF Dosyaları (*.*)|*.pdf*";
            pdfsec.FilterIndex = 1;
           // pdfsec.Multiselect = true;

            if (pdfsec.ShowDialog() == DialogResult.OK)
            {
                dosyayolu = pdfsec.FileName;
               // string[] arrAllFiles = pdfsec.FileNames; //multiselect seçili ise kullan       
            }
            
            txtpdf.Text = dosyayolu;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }
    }
}
