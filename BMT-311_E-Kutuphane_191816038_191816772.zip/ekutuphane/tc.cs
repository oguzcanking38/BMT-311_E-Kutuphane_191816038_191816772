﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ekutuphane
{
    
    static class tc
    {

        public static string tcno2;
        public static string pdflink;

    }
}
