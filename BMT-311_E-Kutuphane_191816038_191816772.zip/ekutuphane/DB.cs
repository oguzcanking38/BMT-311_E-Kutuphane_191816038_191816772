﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Npgsql;

namespace ekutuphane
{
    class DB
    {
        static public int gonder(string sorgu)
        {

            var cs = "Host=localhost;Username=postgres;Password=123;Database=kutupdb";

            var con = new NpgsqlConnection(cs);
            con.Open();

            var sql = sorgu;

            var cmd = new NpgsqlCommand(sql, con);

            NpgsqlDataReader rdr = cmd.ExecuteReader();

            int i=0;
            if (rdr.Read())
            {
                Console.WriteLine("gg");
                i = 1;
            }
            else
            {
                Console.WriteLine("bad game");
            }

            con.Close();

            return i;
        }

        static public int gonder2(string sorgu)
        {

            var cs = "Host=localhost;Username=postgres;Password=123;Database=kutupdb";

            var con = new NpgsqlConnection(cs);
            con.Open();

            var sql = sorgu;

            var cmd = new NpgsqlCommand(sql, con);

            NpgsqlDataReader rdr = cmd.ExecuteReader();

            int i = 0;
            while (rdr.Read())
            {
                i = Int32.Parse(rdr[7].ToString());
                
            }

            con.Close();

            return i;
        }

        static public int gondersorgu(string sorgu)
        {
            var cs = "Host=localhost;Username=postgres;Password=123;Database=kutupdb";

            var con = new NpgsqlConnection(cs);
            con.Open();

            var sql = sorgu;

            NpgsqlCommand cmd = new NpgsqlCommand(sorgu, con);

            int i = cmd.ExecuteNonQuery();
            con.Close();

            return i;

        }
        static public void baglantiac()
        {
            var cs = "Host=localhost;Username=postgres;Password=123;Database=kutupdb";

            var con = new NpgsqlConnection(cs);
            con.Open();
        }

        static public void baglantikapat()
        {
            var cs = "Host=localhost;Username=postgres;Password=123;Database=kutupdb";

            var con = new NpgsqlConnection(cs);
            con.Close();
        }
    }
   

}
