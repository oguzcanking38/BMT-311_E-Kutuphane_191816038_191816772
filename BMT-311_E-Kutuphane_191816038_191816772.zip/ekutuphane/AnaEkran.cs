﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MaterialSkin.Controls;
using Npgsql;

namespace ekutuphane
{
    public partial class AnaEkran : MaterialForm
    {
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        string filterField = "kitapadi";
        public AnaEkran()
        {
            InitializeComponent();
        }

        private void AnaEkran_Load(object sender, EventArgs e)
        {
            
            
            var cs = "Host=localhost;Username=postgres;Password=123;Database=kutupdb";

            var con = new NpgsqlConnection(cs);
            
            con.Open();
            string sql = "SELECT * FROM kitaplar";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sql, con);
            ds.Reset();
            da.Fill(ds);
            dt = ds.Tables[0];
            dataGridView1.DataSource = dt;
            con.Close();


        }

        private void materialFlatButton1_Click(object sender, EventArgs e)
        {

            Pdf kyt = new Pdf();
            kyt.Show();

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            dataGridView1.CurrentRow.Selected = true;
            tc.pdflink = dataGridView1.Rows[e.RowIndex].Cells["pdfadres"].FormattedValue.ToString();

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            dt.DefaultView.RowFilter = string.Format("[{0}] LIKE '%{1}%'", filterField, textBox1.Text);
        }
    }
}
