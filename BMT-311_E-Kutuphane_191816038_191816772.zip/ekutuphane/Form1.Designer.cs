﻿namespace ekutuphane
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.materialLabel1 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel2 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel3 = new MaterialSkin.Controls.MaterialLabel();
            this.emailBox = new System.Windows.Forms.TextBox();
            this.sifreBox = new System.Windows.Forms.TextBox();
            this.girisbuton1 = new MaterialSkin.Controls.MaterialFlatButton();
            this.sifreunutlabel = new System.Windows.Forms.Label();
            this.kayitbuton1 = new MaterialSkin.Controls.MaterialFlatButton();
            this.SuspendLayout();
            // 
            // materialLabel1
            // 
            this.materialLabel1.AutoSize = true;
            this.materialLabel1.Depth = 0;
            this.materialLabel1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.materialLabel1.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel1.Location = new System.Drawing.Point(259, 108);
            this.materialLabel1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel1.Name = "materialLabel1";
            this.materialLabel1.Size = new System.Drawing.Size(92, 19);
            this.materialLabel1.TabIndex = 0;
            this.materialLabel1.Text = "E-Kütüphane";
            // 
            // materialLabel2
            // 
            this.materialLabel2.AutoSize = true;
            this.materialLabel2.Depth = 0;
            this.materialLabel2.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel2.Location = new System.Drawing.Point(153, 178);
            this.materialLabel2.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel2.Name = "materialLabel2";
            this.materialLabel2.Size = new System.Drawing.Size(51, 19);
            this.materialLabel2.TabIndex = 1;
            this.materialLabel2.Text = "E-Mail";
            // 
            // materialLabel3
            // 
            this.materialLabel3.AutoSize = true;
            this.materialLabel3.Depth = 0;
            this.materialLabel3.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel3.Location = new System.Drawing.Point(153, 212);
            this.materialLabel3.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel3.Name = "materialLabel3";
            this.materialLabel3.Size = new System.Drawing.Size(40, 19);
            this.materialLabel3.TabIndex = 2;
            this.materialLabel3.Text = "Şifre";
            // 
            // emailBox
            // 
            this.emailBox.Location = new System.Drawing.Point(210, 177);
            this.emailBox.Name = "emailBox";
            this.emailBox.Size = new System.Drawing.Size(180, 20);
            this.emailBox.TabIndex = 3;
            // 
            // sifreBox
            // 
            this.sifreBox.Location = new System.Drawing.Point(210, 211);
            this.sifreBox.Name = "sifreBox";
            this.sifreBox.Size = new System.Drawing.Size(180, 20);
            this.sifreBox.TabIndex = 4;
            // 
            // girisbuton1
            // 
            this.girisbuton1.AutoSize = true;
            this.girisbuton1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.girisbuton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.girisbuton1.Depth = 0;
            this.girisbuton1.Location = new System.Drawing.Point(407, 178);
            this.girisbuton1.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.girisbuton1.MinimumSize = new System.Drawing.Size(75, 50);
            this.girisbuton1.MouseState = MaterialSkin.MouseState.HOVER;
            this.girisbuton1.Name = "girisbuton1";
            this.girisbuton1.Primary = false;
            this.girisbuton1.Size = new System.Drawing.Size(75, 50);
            this.girisbuton1.TabIndex = 5;
            this.girisbuton1.Text = "Giriş";
            this.girisbuton1.UseVisualStyleBackColor = true;
            this.girisbuton1.Click += new System.EventHandler(this.girisbuton_Click);
            // 
            // sifreunutlabel
            // 
            this.sifreunutlabel.AutoSize = true;
            this.sifreunutlabel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sifreunutlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sifreunutlabel.ForeColor = System.Drawing.SystemColors.Highlight;
            this.sifreunutlabel.Location = new System.Drawing.Point(277, 245);
            this.sifreunutlabel.Name = "sifreunutlabel";
            this.sifreunutlabel.Size = new System.Drawing.Size(99, 16);
            this.sifreunutlabel.TabIndex = 6;
            this.sifreunutlabel.Text = "Şifremi Unuttum";
            this.sifreunutlabel.Click += new System.EventHandler(this.sifreunutlabel_Click);
            // 
            // kayitbuton1
            // 
            this.kayitbuton1.AutoSize = true;
            this.kayitbuton1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.kayitbuton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.kayitbuton1.Depth = 0;
            this.kayitbuton1.Location = new System.Drawing.Point(199, 304);
            this.kayitbuton1.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.kayitbuton1.MinimumSize = new System.Drawing.Size(200, 75);
            this.kayitbuton1.MouseState = MaterialSkin.MouseState.HOVER;
            this.kayitbuton1.Name = "kayitbuton1";
            this.kayitbuton1.Primary = false;
            this.kayitbuton1.Size = new System.Drawing.Size(200, 75);
            this.kayitbuton1.TabIndex = 7;
            this.kayitbuton1.Text = "Kayıt Ol";
            this.kayitbuton1.UseVisualStyleBackColor = true;
            this.kayitbuton1.Click += new System.EventHandler(this.kayitbuton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(609, 456);
            this.Controls.Add(this.kayitbuton1);
            this.Controls.Add(this.sifreunutlabel);
            this.Controls.Add(this.girisbuton1);
            this.Controls.Add(this.sifreBox);
            this.Controls.Add(this.emailBox);
            this.Controls.Add(this.materialLabel3);
            this.Controls.Add(this.materialLabel2);
            this.Controls.Add(this.materialLabel1);
            this.Name = "Form1";
            this.Text = "E-Kütüphane";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MaterialSkin.Controls.MaterialLabel materialLabel1;
        private MaterialSkin.Controls.MaterialLabel materialLabel2;
        private MaterialSkin.Controls.MaterialLabel materialLabel3;
        private System.Windows.Forms.TextBox emailBox;
        private System.Windows.Forms.TextBox sifreBox;
        private MaterialSkin.Controls.MaterialFlatButton girisbuton1;
        private System.Windows.Forms.Label sifreunutlabel;
        private MaterialSkin.Controls.MaterialFlatButton kayitbuton1;
    }
}

