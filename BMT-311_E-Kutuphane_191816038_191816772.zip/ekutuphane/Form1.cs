﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MaterialSkin.Controls;

namespace ekutuphane
{
    public partial class Form1 : MaterialForm
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void sifreunutlabel_Click(object sender, EventArgs e)
        {
            Sifreunut sfr = new Sifreunut();
            sfr.Show();

        }

        private void girisbuton_Click(object sender, EventArgs e)
        {
            string email = emailBox.Text;
            string sifre = sifreBox.Text;
            string sorgu = "select * from kullanicilar where " + $"email='{email}'" +" " + "AND" + " " + $"sifre='{sifre}'";
            Console.WriteLine(sorgu);
            int dogrulama = DB.gonder2(sorgu);
            if (dogrulama == 1)
            {
                MessageBox.Show("Giriş Başarılı");

                AnaEkran kyt = new AnaEkran();
                kyt.Show();
            }
            else if (dogrulama >=2)
            {
                MessageBox.Show("Hoşgeldin Admin");

                Adminpanel kyt = new Adminpanel();
                kyt.Show();
            }
            else
            {
                MessageBox.Show("Giriş Başarısız");

            }
        }

        private void kayitbuton_Click(object sender, EventArgs e)
        {
            Kayit kyt = new Kayit();
            kyt.Show();

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
