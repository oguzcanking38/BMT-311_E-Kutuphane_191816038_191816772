﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MaterialSkin.Controls;
using System.Net.Mail;
namespace ekutuphane
{
    
    public partial class Sifreunut : MaterialForm
    {
        static class tcno
        {
            public static string tcno2;
        }
        public Sifreunut()
        {
            InitializeComponent();
        }

        private void Sifreunut_Load(object sender, EventArgs e)
        {

        }

        private void gonderbuton_Click(object sender, EventArgs e)
        {

            string email = textemail.Text;
            tc.tcno2 = texttc.Text;
            Random rd = new Random();
            int rand_num = rd.Next(10000000, 90000000);

            

            string sorgu = "update kurtarma set kurtarmakod = " + $"'{rand_num}'" + "where kimlikno = " + $"'{tc.tcno2}'";
            int dogrulama = DB.gondersorgu(sorgu);
            if (dogrulama > 0)
            {
                MessageBox.Show("E-Postanızı Kontrol Edniz");
                Emailkod kyt = new Emailkod();
                kyt.Show();
            }
            else
            {
                MessageBox.Show("Bilgilerinizi Tekrar Giriniz");
            }
            try
            {



                MailMessage mail = new MailMessage();
                SmtpClient SmtpServer = new SmtpClient("smtp.gmail.com");

                mail.From = new MailAddress("ekutuphane.gazi@gmail.com");
                mail.To.Add(email);
                mail.Subject = "E-Kütüphane Şifre Kurtarma Kodunuz";
                mail.Body = "Kodunuz:" + $"'{rand_num}'";

                SmtpServer.Port = 587;
                SmtpServer.Credentials = new System.Net.NetworkCredential("ekutuphane.gazi", "pFoknq4z+^R?0IAl");
                SmtpServer.EnableSsl = true;

                SmtpServer.Send(mail);
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
    }
}
