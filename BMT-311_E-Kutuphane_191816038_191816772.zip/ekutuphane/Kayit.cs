﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MaterialSkin.Controls;
using Npgsql;
namespace ekutuphane
{
    public partial class Kayit : MaterialForm
    {
        public Kayit()
        {
            InitializeComponent();
        }

        private void Kayit_Load(object sender, EventArgs e)
        {

        }

        private void kayitolbuton_Click(object sender, EventArgs e)
        {
            if (textsifre.Text == textsifre2.Text)
            {
                string ad = textad.Text;
                string soyad = textsoyad.Text;
                string email = textemail.Text;
                string telno = texttel.Text;
                string adres = textadres.Text;
                string kimlikno = textno.Text;
                string sifre = textsifre.Text;
                string sorgu = "insert into kullanicilar (soyad,email,telno,adres,kimlikno,sifre,ad) " + "values(" + $"'{soyad}'" + "," + $"'{email}'" + "," + $"'{telno}'" + "," + $"'{adres}'" + "," + $"'{kimlikno}'" + "," + $"'{sifre}'" + "," + $"'{ad}'" + ")";
                int dogrulama = DB.gondersorgu(sorgu);
                if (dogrulama > 0)
                {
                    MessageBox.Show("Kayıt Başarılı");
                }
                else
                {
                    MessageBox.Show("Kayıt Başarısız");
                }

            }
            else
            {
                MessageBox.Show("Girdiğiniz Şifreler Eşleşmedi");
            }
        }
    }
}
