﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MaterialSkin.Controls;

namespace ekutuphane
{
    public partial class Emailkod : MaterialForm
    {
        public Emailkod()
        {
            InitializeComponent();
        }

        private void Emailkod_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void materialFlatButton1_Click(object sender, EventArgs e)
        {
            string kod = textBox1.Text;
            string yenisifre = textBox2.Text;
            

            string sorgu = "select * from kurtarma where " + $"kurtarmakod='{kod}'";

            string sorgu2 = "update kullanicilar set sifre = "+ $"'{yenisifre}'" + "where kimlikno = " + $"'{tc.tcno2}'";

            string sorgu3 = "update kurtarma set kurtarmakod = 0 " + "where kimlikno = " + $"'{tc.tcno2}'";

            int dogrulama = DB.gonder(sorgu);
            int dogrulama2 = DB.gondersorgu(sorgu2);
            int dogrulama3 = DB.gondersorgu(sorgu3);

            if ((dogrulama == 1) && (dogrulama2 == 1) && (dogrulama3 == 1))
            {
                MessageBox.Show("Şifreniz Değiştirildi");
            }
            else
            {
                MessageBox.Show("Şifreniz Değiştirilemedi");
            }


        }
    }
}
