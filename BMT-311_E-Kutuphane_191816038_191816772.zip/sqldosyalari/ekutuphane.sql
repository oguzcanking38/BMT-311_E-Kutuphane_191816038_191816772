--
-- PostgreSQL database dump
--

-- Dumped from database version 12.9
-- Dumped by pg_dump version 12.9

-- Started on 2022-01-11 01:56:29

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 208 (class 1255 OID 24577)
-- Name: kitapekle(character varying, character varying, character varying, character varying, character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.kitapekle(g_isbn character varying, g_yazar character varying, g_kitapadi character varying, g_kategori character varying, g_pdfadres character varying)
    LANGUAGE plpgsql
    AS $$
begin
INSERT INTO kitaplar(isbn, yazar, kitapadi, kategori, pdfadres)
	VALUES (g_isbn, g_yazar, g_kitapadi, g_kategori, g_pdfadres);
end;
$$;


ALTER PROCEDURE public.kitapekle(g_isbn character varying, g_yazar character varying, g_kitapadi character varying, g_kategori character varying, g_pdfadres character varying) OWNER TO postgres;

--
-- TOC entry 209 (class 1255 OID 24578)
-- Name: kitapguncelle(integer, character varying, character varying, character varying, character varying, character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.kitapguncelle(g_kitapid integer, g_isbn character varying, g_yazar character varying, g_kitapadi character varying, g_kategori character varying, g_pdfadres character varying)
    LANGUAGE plpgsql
    AS $$
begin
update kitaplar set isbn = g_isbn, yazar = g_yazar, kitapadi=g_kitapadi, kategori = g_kategori, pdfadres = g_pdfadres where kitapid = g_kitapid;
end;
$$;


ALTER PROCEDURE public.kitapguncelle(g_kitapid integer, g_isbn character varying, g_yazar character varying, g_kitapadi character varying, g_kategori character varying, g_pdfadres character varying) OWNER TO postgres;

--
-- TOC entry 210 (class 1255 OID 24579)
-- Name: kitapsil(integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.kitapsil(g_kitapid integer)
    LANGUAGE plpgsql
    AS $$
begin
delete from kitaplar where kitapid = g_kitapid;
end;
$$;


ALTER PROCEDURE public.kitapsil(g_kitapid integer) OWNER TO postgres;

--
-- TOC entry 211 (class 1255 OID 24580)
-- Name: kurtarma1(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.kurtarma1() RETURNS trigger
    LANGUAGE plpgsql
    AS $$Begin
if (TG_OP = 'INSERT') then
insert into kurtarma(kimlikno) values(new.kimlikno);
return null;
end if;
end;$$;


ALTER FUNCTION public.kurtarma1() OWNER TO postgres;

--
-- TOC entry 212 (class 1255 OID 24581)
-- Name: kurtarmasifrekimlikno(); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.kurtarmasifrekimlikno()
    LANGUAGE sql
    AS $$select kimlikno from kullanicilar;$$;


ALTER PROCEDURE public.kurtarmasifrekimlikno() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 202 (class 1259 OID 24582)
-- Name: kitaplar; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kitaplar (
    kitapid integer NOT NULL,
    isbn character varying(13),
    yazar character varying(55),
    kitapadi character varying(95),
    kategori character varying(25),
    pdfadres character varying(255)
);


ALTER TABLE public.kitaplar OWNER TO postgres;

--
-- TOC entry 203 (class 1259 OID 24585)
-- Name: Kitaplar_kitapid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.kitaplar ALTER COLUMN kitapid ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public."Kitaplar_kitapid_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 204 (class 1259 OID 24587)
-- Name: kullanicilar; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kullanicilar (
    id integer NOT NULL,
    soyad character varying(25) NOT NULL,
    email character varying(320) NOT NULL,
    telno character varying(11) NOT NULL,
    adres character varying(320) NOT NULL,
    kimlikno character varying(11) NOT NULL,
    sifre character varying(64) NOT NULL,
    seviye integer DEFAULT 1 NOT NULL,
    ad character varying(25) NOT NULL
);


ALTER TABLE public.kullanicilar OWNER TO postgres;

--
-- TOC entry 2860 (class 0 OID 0)
-- Dependencies: 204
-- Name: TABLE kullanicilar; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.kullanicilar IS 'Kullanıcılar Tablosu';


--
-- TOC entry 2861 (class 0 OID 0)
-- Dependencies: 204
-- Name: COLUMN kullanicilar.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.kullanicilar.id IS 'Kullanıcı ID';


--
-- TOC entry 205 (class 1259 OID 24594)
-- Name: kullanicilar_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.kullanicilar ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.kullanicilar_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 206 (class 1259 OID 24596)
-- Name: kurtarma; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kurtarma (
    kimlikno character varying(11) NOT NULL,
    kurtarmakod character varying(10)
);


ALTER TABLE public.kurtarma OWNER TO postgres;

--
-- TOC entry 207 (class 1259 OID 24599)
-- Name: seviyeler; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.seviyeler (
    seviyeid integer NOT NULL,
    seviyeadi character varying(25)
);


ALTER TABLE public.seviyeler OWNER TO postgres;

--
-- TOC entry 2862 (class 0 OID 0)
-- Dependencies: 207
-- Name: TABLE seviyeler; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.seviyeler IS 'Seviye Tablosu (Admin Personel Kullanıcı)';


--
-- TOC entry 2849 (class 0 OID 24582)
-- Dependencies: 202
-- Data for Name: kitaplar; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.kitaplar (kitapid, isbn, yazar, kitapadi, kategori, pdfadres) OVERRIDING SYSTEM VALUE VALUES (8, '12345678', 'testyenipc', 'yenipc', 'yenicpc', 'C:\Users\oguzc\Downloads\1919B012105459.pdf');
INSERT INTO public.kitaplar (kitapid, isbn, yazar, kitapadi, kategori, pdfadres) OVERRIDING SYSTEM VALUE VALUES (9, '12345679', 'Faruk', 'Web Development', 'Bilişim', 'C:\Users\oguzc\Downloads\bigg-yesil_buyume_cagrisi_duyurusu_23082021.pdf');
INSERT INTO public.kitaplar (kitapid, isbn, yazar, kitapadi, kategori, pdfadres) OVERRIDING SYSTEM VALUE VALUES (7, '12345', 'Gazi', 'tfbm2', 'test3', 'C:\Users\Oğuz (OQUS)\Downloads\191816038_Oğuz_Can_Kısa_Biçimsel_Diller_Ve_Otomata_Petrinet_Ödevi (1).pdf');
INSERT INTO public.kitaplar (kitapid, isbn, yazar, kitapadi, kategori, pdfadres) OVERRIDING SYSTEM VALUE VALUES (10, '123456780', 'Oğuz', 'c#2', 'Bilişim', 'C:\Users\oguzc\Downloads\31549362700_Transkript (1) (1).pdf');


--
-- TOC entry 2851 (class 0 OID 24587)
-- Dependencies: 204
-- Data for Name: kullanicilar; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.kullanicilar (id, soyad, email, telno, adres, kimlikno, sifre, seviye, ad) OVERRIDING SYSTEM VALUE VALUES (1, 'can', 'oguzcankisa.ce@gmail.com', '5459772395', 'Ankara', '10500515814', '123', 3, 'oguz');
INSERT INTO public.kullanicilar (id, soyad, email, telno, adres, kimlikno, sifre, seviye, ad) OVERRIDING SYSTEM VALUE VALUES (36, 'Akan', 'h.melihakan@gmail.com', '5372058619', 'sjdfhkjshfksjhdkjfhjkhkjhkjhjkkjh', '46510045094', '123456', 1, 'Melih');
INSERT INTO public.kullanicilar (id, soyad, email, telno, adres, kimlikno, sifre, seviye, ad) OVERRIDING SYSTEM VALUE VALUES (35, 'Admin', 'oguzcanking38@hotmail.com', '5459772397', 'Çankaya', '10300515816', '123', 3, 'Admin');
INSERT INTO public.kullanicilar (id, soyad, email, telno, adres, kimlikno, sifre, seviye, ad) OVERRIDING SYSTEM VALUE VALUES (37, 'test', 'oguzcanking900@hotmail.com', '5459772394', 'Çankaya', '10300515812', '12345', 1, 'test');


--
-- TOC entry 2853 (class 0 OID 24596)
-- Dependencies: 206
-- Data for Name: kurtarma; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.kurtarma (kimlikno, kurtarmakod) VALUES ('1', NULL);
INSERT INTO public.kurtarma (kimlikno, kurtarmakod) VALUES ('23', NULL);
INSERT INTO public.kurtarma (kimlikno, kurtarmakod) VALUES ('123', '81252918');
INSERT INTO public.kurtarma (kimlikno, kurtarmakod) VALUES ('10300515813', '0');
INSERT INTO public.kurtarma (kimlikno, kurtarmakod) VALUES ('46510045094', '0');
INSERT INTO public.kurtarma (kimlikno, kurtarmakod) VALUES ('10300515816', '0');
INSERT INTO public.kurtarma (kimlikno, kurtarmakod) VALUES ('10300515812', '0');


--
-- TOC entry 2854 (class 0 OID 24599)
-- Dependencies: 207
-- Data for Name: seviyeler; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.seviyeler (seviyeid, seviyeadi) VALUES (1, 'Kullanıcı');
INSERT INTO public.seviyeler (seviyeid, seviyeadi) VALUES (2, 'Personel');
INSERT INTO public.seviyeler (seviyeid, seviyeadi) VALUES (3, 'Admin');


--
-- TOC entry 2863 (class 0 OID 0)
-- Dependencies: 203
-- Name: Kitaplar_kitapid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Kitaplar_kitapid_seq"', 10, true);


--
-- TOC entry 2864 (class 0 OID 0)
-- Dependencies: 205
-- Name: kullanicilar_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.kullanicilar_id_seq', 37, true);


--
-- TOC entry 2709 (class 2606 OID 24603)
-- Name: kitaplar Kitaplar_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kitaplar
    ADD CONSTRAINT "Kitaplar_pkey" PRIMARY KEY (kitapid);


--
-- TOC entry 2711 (class 2606 OID 24605)
-- Name: kullanicilar emailref; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kullanicilar
    ADD CONSTRAINT emailref UNIQUE (email);


--
-- TOC entry 2713 (class 2606 OID 24607)
-- Name: kullanicilar kimliknoref; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kullanicilar
    ADD CONSTRAINT kimliknoref UNIQUE (kimlikno);


--
-- TOC entry 2715 (class 2606 OID 24609)
-- Name: kullanicilar kullanicilar_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kullanicilar
    ADD CONSTRAINT kullanicilar_pkey PRIMARY KEY (id);


--
-- TOC entry 2717 (class 2606 OID 24611)
-- Name: kurtarma kurtarma_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kurtarma
    ADD CONSTRAINT kurtarma_pkey PRIMARY KEY (kimlikno);


--
-- TOC entry 2719 (class 2606 OID 24613)
-- Name: seviyeler seviyeler_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.seviyeler
    ADD CONSTRAINT seviyeler_pkey PRIMARY KEY (seviyeid);


--
-- TOC entry 2721 (class 2620 OID 24614)
-- Name: kullanicilar kurtarmatrigger; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER kurtarmatrigger BEFORE INSERT ON public.kullanicilar FOR EACH ROW EXECUTE FUNCTION public.kurtarma1();

ALTER TABLE public.kullanicilar DISABLE TRIGGER kurtarmatrigger;


--
-- TOC entry 2722 (class 2620 OID 24615)
-- Name: kullanicilar kurtarmatrigger2; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER kurtarmatrigger2 AFTER INSERT ON public.kullanicilar FOR EACH ROW EXECUTE FUNCTION public.kurtarma1();


--
-- TOC entry 2720 (class 2606 OID 24616)
-- Name: kurtarma kimlikref; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kurtarma
    ADD CONSTRAINT kimlikref FOREIGN KEY (kimlikno) REFERENCES public.kullanicilar(kimlikno) NOT VALID;


-- Completed on 2022-01-11 01:56:30

--
-- PostgreSQL database dump complete
--

